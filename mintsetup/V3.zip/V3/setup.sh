#!/bin/bash

function initval {
	local store=$1 id=$2

	if ! grep -q "^$id=" "/opt/lurux-mintsetup/$store"
	then
		echo "$id=" >> "/opt/lurux-mintsetup/$store"
	fi
}

function getval {
	local store=$1 id=$2
	grep "^$id=" "/opt/lurux-mintsetup/$store" | cut -d '=' -f 2
}

function setval {
	local store=$1 id=$2 val=$3
	sed -i "s/$id=.*/$id=$val/g" "/opt/lurux-mintsetup/$store"
}

function get {
	while true
	do
		read -p "[y]es / [n]o > " q

		case $q in
			y) echo; true; return;;
			n) echo; false; return;;
			*) echo;;
		esac
	done
}

# printf "\e[1m[y]\e[0mes / \e[1m[n]\e[0mo > "

function prbl {
	printf "\n\n\e[1m$1\e[0m\n"
}

function prompt_cmd {
	local cmd=$1
	printf "\n\e[1mThe following commands will be run:\e[0m\n$cmd\n\e[1mPress [enter] to continue, [escape] to cancel\e[0m"

	while true
	do
		read -s -n1 q

		case $q in
			'')
				printf "\n\n"
				eval "$cmd"
				echo "All done !"
				true
				return ;;
			$'\e')
				printf "\n\n\e[2m(Not run)\e[0m\n"
				false
				return ;;
		esac
	done
}

function prompt_script {
	local cmd=$1 when=$2
	printf "\n\e[1mThe following commands will be run at startup:\e[0m\n$cmd\n\e[1mPress [enter] to continue, [escape] to cancel\e[0m"

	while true
	do
		read -s -n1 q

		case $q in
			'')
				printf "\n\n"
				eval "$cmd"
				echo "$cmd" >> startup.sh
				echo "Added !"
				true
				return ;;
			$'\e')
				printf "\n\n\e[2m(Not added)\e[0m\n"
				false
				return ;;
		esac
	done
}

function prompt {
	local id title description actual_value actual_cmd rec_value rec_cmd default_value default_cmd chk_info chk_cmd
	local "${@}"

	if [ -n "$chk_cmd" ]
	then
		if ! eval $chk_cmd
		then
			printf "\nNote: $id is not recomended for your configuration: $chk_info. Show this step anyways ?\n"
			if ! get
			then
				printf "\e[2mSkipping $id...\e[0m\n"
				return
			fi
		fi
	fi

	initval default $id
	initval expected $id

	local configured_value=$( getval expected $id )

	if [ -z "$default_value" ]
	then
		[ -z "$configured_value" ] && ( setval default $id "$actual_value" )
		default_value=$( getval default $id )
	fi

	if [ "$default_value" = "$rec_value" ]
	then
		printf "\n\e[2mSkipping $id: system default value matches recomended value...\e[0m\n"
		return
	fi

	printf "\n\e[1m$title\e[0m\n"
	printf "$description\n"

	if [ -z "$configured_value" ]
	then
		printf "Currently set to: \e[1msystem default\e[0m ($actual_value)\n"
	else
		printf "Currently set to: \e[1m$configured_value\e[0m\n"
		[ "$actual_value" != "$configured_value" ] && ( printf "\e[33mWarning: Actual value \e[1m($actual_value)\e[22m does not match configured value \e[1m($configured_value)\e[0m\n" )
		[ "$configured_value" != "$rec_value" ] && ( printf "\e[36mNote: Configured value \e[1m($configured_value)\e[22m does not match new recomendation \e[1m($rec_value)\e[0m\n" )
	fi

	if [ -z "$actual_cmd" ]
	then
		while true
		do
			printf "\n\e[1m[d]\e[0mefault: $default_value / \e[1m[r]\e[0mecomended: $rec_value / \e[1m[n]\e[0mo change > "
			read q

			case $q in
				d)
					prompt_cmd "$default_cmd" && setval expected $id "" && break ;;
				r)
					prompt_cmd "$rec_cmd" && setval expected $id "$rec_value" && break ;;
				n)
					printf "\n\e[2m(No change)\e[0m\n" ; setval expected $id "$actual_value" ; break ;;
			esac
		done
	else
		while true
		do
			printf "\n\e[1m[d]\e[0mefault: $default_value / \e[1m[r]\e[0mecomended: $rec_value / \e[1m[n]\e[0mo change > "
			read q

			case $q in
				d)
					printf "\n\e[2m(Nothing will be run)\e[0m\n" ; setval expected $id "" ; break ;;
				r)
					prompt_script "$rec_cmd" && setval expected $id "$rec_value" && break ;;
				n)
					prompt_script "$actual_cmd" && setval expected $id "$actual_value" && break ;;
			esac
		done
	fi
}



prbl "****** Preliminary Info ******"

disk=$( lsblk -rno MOUNTPOINT,PKNAME | grep "^/ " | cut -d ' ' -f 2 )

printf "\nAssuming your main disk is \e[1m$disk\e[0m. Is that correct ?\n"

if ! get
then
	read -p "Please type in your disk identifier > " q
	disk=$q
	printf "\n"
fi

ram=$( free --giga | awk '/^Mem:/{print $2}' )

if [ $( cat "/sys/block/$disk/queue/rotational" ) = 1 ]
then
	printf "Note: your RAM is $ram GB, and your disk is an HDD.\n"
	disk_type="hdd"
else
	printf "Note: your RAM is $ram GB, and your disk is an SSD.\n"
	disk_type="ssd"
fi



prbl "****** Initial Setup (1/6) ******"

printf "\nThis script will update the system package information, then guide you through configuring it.\n"

if ! prompt_cmd "apt update"
then
	printf "Exiting script...\n"
	exit 1
fi

printf "\nPreparing script...\n"

if ! prompt_cmd "mkdir -p /opt/lurux-mintsetup
touch /opt/lurux-mintsetup/default
touch /opt/lurux-mintsetup/expected"
then
	printf "Exiting script...\n"
	exit 1
fi

echo "#!/bin/sh" > startup.sh

printf "\nApply updates before starting ?\n"

if get
then
	prompt_cmd "apt upgrade"
fi



prbl "****** Disk Performance (2/6) ******"

if [ "$disk_type" = "ssd" ]
then
	diskperf_rec_value="256"
else
	diskperf_rec_value="1024"
fi

prompt \
id="diskperf" \
title="Increase disk read-ahead on startup ?" \
description="This should improve application startup times, especially on HDDs" \
actual_value="$( cat /sys/block/$disk/queue/read_ahead_kb )" \
actual_cmd="echo $( cat /sys/block/$disk/queue/read_ahead_kb ) > /sys/block/$disk/queue/read_ahead_kb" \
rec_value="$diskperf_rec_value" \
rec_cmd="echo $diskperf_rec_value > /sys/block/$disk/queue/read_ahead_kb"



prbl "****** Memory Management (3/6) ******"

prompt \
id="zram" \
title="Install compressed RAM ?" \
description="This makes operation on low memory much smoother" \
actual_value="$( dpkg -l systemd-zram-generator &>/dev/null && echo 'installed' || echo 'not installed' )" \
rec_value="installed" \
rec_cmd="apt install systemd-zram-generator" \
default_cmd="apt remove systemd-zram-generator"

if ! [ -f "/etc/systemd/zram-generator.conf.bak" ]
then
	zram_default_cmd="# Unable to reset config: backup file not found"
	zram_rec_cmd="cp /etc/systemd/zram-generator.conf /etc/systemd/zram-generator.conf.bak
cp ./zram-generator.conf /etc/systemd/zram-generator.conf"
else
	zram_default_cmd="mv /etc/systemd/zram-generator.conf.bak /etc/systemd/zram-generator.conf"
	zram_rec_cmd="# Original config already backed up
cp ./zram-generator.conf /etc/systemd/zram-generator.conf"
fi

zram_actual_value=$( grep "^#lurux-mintsetup" "/etc/systemd/zram-generator.conf" | cut -c 2- )

if [ -z "$zram_actual_value" ]
then
	zram_actual_value="system default"
fi

prompt \
id="zram-config" \
title="Use recomended config ?" \
description="Increase maximum size and use ZSTD for compression" \
actual_value="$zram_actual_value" \
rec_value="lurux-mintsetup-0.0.3" \
default_value="system default" \
rec_cmd="$zram_rec_cmd" \
default_cmd="$zram_default_cmd"

prompt \
id="ramperf" \
title="Increase preemptive swapping ?" \
description="This makes operation on low memory much smoother, espacially paired with zRAM" \
actual_value="$(( $( cat /proc/sys/vm/min_free_kbytes ) / 128 )) + 0.$(( $( cat /proc/sys/vm/watermark_scale_factor ) / 10 ))%%" \
actual_cmd="echo $( cat /proc/sys/vm/watermark_scale_factor ) > /proc/sys/vm/watermark_scale_factor
echo $( cat /proc/sys/vm/min_free_kbytes ) > /proc/sys/vm/min_free_kbytes" \
rec_value="1024 + 0.2%%" \
rec_cmd="echo 20 > /proc/sys/vm/watermark_scale_factor
echo 131072 > /proc/sys/vm/min_free_kbytes"



prbl "****** CPU Optimization (4/6) ******"

printf "\nNot yet implemented !\n"



prbl "****** System Services (5/6) ******"

max_logs_actual_value=$( grep "^SystemMaxUse=" "/etc/systemd/journald.conf" | cut -d '=' -f 2 )

if [ -z "$max_logs_actual_value" ]
then
	max_logs_actual_value="unlimited"
fi

max_logs_default_value="$( getval expected 'max-logs' )"
max_logs_default_cmd="sed -i /SystemMaxUse/c\SystemMaxUse=$max_logs_default_value /etc/systemd/journald.conf"

if [ -z "$max_logs_default_value" ]
then
	max_logs_default_value="$max_logs_actual_value"
	max_logs_default_cmd="sed -i /SystemMaxUse/c\#SystemMaxUse /etc/systemd/journald.conf"
fi

prompt \
id="max-logs" \
title="Limit system logs to 128M ?" \
description="This is recomended to save storage, and may improve boot times" \
actual_value="$max_logs_actual_value" \
rec_value="128M" \
rec_cmd="sed -i /SystemMaxUse/c\SystemMaxUse=128M /etc/systemd/journald.conf" \
default_cmd="$max_logs_default_cmd"



prbl "****** Flatpak Applications (6/6) ******"

prompt \
id="lo-flatpak" \
title="Use Flatpak version of LibreOffice ?" \
description="Get a newer version of LibreOffice" \
actual_value="$( ( flatpak list | grep libreoffice &>/dev/null ) && echo 'flatpak' || echo 'debian' )" \
rec_value="flatpak" \
rec_cmd="apt remove libreoffice*
flatpak install org.libreoffice.LibreOffice" \
default_cmd="flatpak remove org.libreoffice.LibreOffice
apt install libreoffice" \
chk_info="Not recomended on HDDs" \
chk_cmd='[ "$disk_type" = "ssd" ]'

prompt \
id="ff-flatpak" \
title="Use Flatpak version of Firefox ?" \
description="Recomended for default version, stability and better updates" \
actual_value="$( ( flatpak list | grep firefox &>/dev/null ) && echo 'flatpak' || echo 'debian' )" \
rec_value="flatpak" \
rec_cmd="apt remove firefox
flatpak install org.mozilla.firefox" \
default_cmd="flatpak remove org.mozilla.firefox
apt install firefox" \
chk_info="Not recomended on HDDs" \
chk_cmd='[ "$disk_type" = "ssd" ]'

prompt \
id="flatseal" \
title="Install Flatseal ?" \
description="Used to manage Flatpak app permissions" \
actual_value="$( ( flatpak list | grep tchx84 &>/dev/null ) && echo 'installed' || echo 'not installed' )" \
rec_value="installed" \
rec_cmd="flatpak install com.github.tchx84.Flatseal" \
default_cmd="flatpak remove com.github.tchx84.Flatseal"



prbl "****** Final Steps ******"

prompt \
id="install" \
title="Let's finalize this !" \
description="Install startup script we just created ?" \
actual_value="$( [ -f /opt/lurux-mintsetup/startup.sh ] && echo 'installed' || echo 'not installed' )" \
rec_value="installed" \
rec_cmd="cp startup.sh /opt/lurux-mintsetup/startup.sh
chmod +x /opt/lurux-mintsetup/startup.sh
mkdir -p /usr/local/lib/systemd/system
cp mintsetup.service /usr/local/lib/systemd/system/mintsetup.service
systemctl enable mintsetup.service" \
default_cmd="systemctl disable mintsetup.service
rm /usr/local/lib/systemd/system/mintsetup.service
rm /opt/lurux-mintsetup/startup.sh"

prompt \
id="pipx" \
title="Install secure Python environment ?" \
description="Avoids system breakage by creating a secure Python environment" \
actual_value="$( dpkg -l pipx &>/dev/null && echo 'installed' || echo 'not installed' )" \
rec_value="installed" \
rec_cmd="apt install pipx
pipx install spyder
cp spyder.desktop /usr/share/applications/spyder.desktop" \
default_cmd="pipx uninstall spyder
apt remove pipx
rm /usr/share/applications/spyder.desktop"

printf "\nClean up unused packages before quitting ?\n"

if get
then
	prompt_cmd "apt autoremove
flatpak remove --unused"
fi

printf "\nShow system recomendations before quitting ?\n"

if get
then
	printf "All done ! Press enter to exit !\n"
	mintwelcome &>/dev/null &
else
	printf "Ok. Press enter to exit !\n"
fi

read -r
